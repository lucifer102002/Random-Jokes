document.addEventListener('DOMContentLoaded', () => {
    const jokeContainer = document.getElementById('joke');
    const jokeButton = document.getElementById('jokeButton');

    async function fetchJoke() {
        try {
            const response = await fetch('https://official-joke-api.appspot.com/random_joke');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const joke = await response.json();
            displayJoke(joke);
        } catch (error) {
            console.error('Error fetching joke:', error);
            jokeContainer.innerHTML = `<p class="text-red-500">Failed to load joke: ${error.message}</p>`;
        }
    }

    function displayJoke(joke) {
        jokeContainer.innerHTML = `
        <p class="text-xl font-semibold mb-2">${joke.setup}</p>
        <p class="text-lg">${joke.punchline}</p>
      `;
    }

    jokeButton.addEventListener('click', fetchJoke);

    // Fetch a joke when the page loads
    fetchJoke();
});